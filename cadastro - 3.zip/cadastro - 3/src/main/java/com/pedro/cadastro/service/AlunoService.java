package com.pedro.cadastro.service;

import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pedro.cadastro.erro.ResourceNotFoundException;
import com.pedro.cadastro.model.Aluno;
import com.pedro.cadastro.model.Proposta;
import com.pedro.cadastro.repository.AlunoRepository;
import com.pedro.cadastro.repository.PropostaRepository;


@Service
public class AlunoService {

	@Autowired
	AlunoRepository clienteRepository;
	
	@Autowired
	PropostaRepository propostaRepository;
		
	//Negocio
	public Aluno cadastrar(Aluno cliente) {
		Aluno cliNovo = clienteRepository.findByCpf(cliente.getCpf());
		System.out.println("Chamou funcao Cadastrar cliente");
		if (cliNovo == null){
			System.out.println("Não existe cliente com esse CPF");
			return clienteRepository.save(cliente);
		}else{
			System.out.println("Existe cliente com esse CPF");
			throw new ResourceNotFoundException("Já existe um cliente com esse CPF cadastrado!");
		}

	}
	
	public Collection< Aluno> buscarTodos(){
		return clienteRepository.findAll();
	}
	
	public void excluir (Aluno cliente) {
		//System.out.println("Chamou funcao excluir cliente");
		verificaSeTemContrato(cliente.getId());
		clienteRepository.delete(cliente);
	}
	
	public Aluno buscarPorId(long id) {
		Aluno cliente = clienteRepository.findById(id);
		return cliente;
	}
		
	public Aluno alterar(Aluno cliente) {
		return clienteRepository.save(cliente);
	}
	
	public Proposta buscarPropostasPorIdCliente(long id) {
		List<Proposta> Propostas = propostaRepository.findAll();
		Proposta pro = null;
		for (int i = 0; i < Propostas.size(); i++) {
			if (Propostas.get(i).getCliente().getId() == id) {
				pro = Propostas.get(i);
			}
		}
		return pro;
	}
	
	public void verificaSeTemContrato(long idCliente){
		Proposta pro = buscarPropostasPorIdCliente(idCliente);
		if(pro == null) {
			System.out.println("Cliente não possui contrato");
		}else {
			//System.out.println("Cliente possui contrato e não pode ser excluido. Contrato: " + pro.getId());
			throw new ResourceNotFoundException("Cliente possui contrato e não pode ser excluido. Contrato: " + pro.getId());
		}
	}
	
}
