# cadastro
Api de cadastro com spring boot

Para rodar o projeto tem criar um banco no Mysql com nome "cadastros"

Porta do banco 3309
