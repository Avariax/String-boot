package com.pedro.cadastro.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.pedro.cadastro.model.Aluno;
import com.pedro.cadastro.model.Usuario;


@Repository
public interface AlunoRepository extends JpaRepository<Aluno, Integer>{
	

	/*
	@Query("SELECT c FROM TAB_CLIENTE c WHERE LOWER(c.id)")
    Cliente findByID(@Param("searchTerm") Integer searchTerm);
	*/
	
	Aluno findByNome(String nome);
	
	Aluno findById(long id);

	Aluno findByCpf(String cpf);

	Aluno findByCurso(long curso);

	Aluno findByTurno(String turno);

		
	

}
