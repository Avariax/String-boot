//criacao de constrollers
appCliente.controller('acessoNegadoController', function ($scope) {
    
})